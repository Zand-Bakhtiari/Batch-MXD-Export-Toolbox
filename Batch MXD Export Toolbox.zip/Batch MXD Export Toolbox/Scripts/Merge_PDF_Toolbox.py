#################################################################################################################
# Script name: Merge_PDF_Toolbox.py
# Author(s): Zand Bakhtiari and Brian Kingary 
# Date : September 9, 2016
# Description: This script will take all PDF documents in a folder and merge 
# them into one PDF document and merge them into a single PDF document in a specified output folder.
#################################################################################################################

# Import Modules
import arcpy, os, glob


# Folder where PDFs will be stored
pdfFolder = arcpy.GetParameterAsText(0)
# Folder where final merged PDF will be stored
pdfname = arcpy.GetParameterAsText(1)
# Name of the finale merged PDF
mergedpdf = arcpy.GetParameterAsText(2)
# Creates a list of the PDF file paths
pdflist = glob.glob(pdfFolder + os.sep + '*.pdf')
# Creates a file path for the final PDF document  
finalpdf = pdfname + os.sep + mergedpdf + '.pdf'


pdfPath = finalpdf
if os.path.exists(pdfPath):
    os.remove(pdfPath)


pdfdoc = arcpy.mapping.PDFDocumentCreate(finalpdf)

i = 0
for pdf in pdflist:
    pdfdoc.appendPages(pdflist[i])
    i+=1
    
    


