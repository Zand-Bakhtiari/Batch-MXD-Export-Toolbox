#################################################################################################################
# Script name: BATCH_MXD_TO_PDF_Toolbox.py
# Author(s): Brian Kingary and Zand Bakhtiari
# Date : September 9, 2016
# Description: This script will take all the MXDs in a folder and export 
# them into individual PDF documents in a specified output folder.
#################################################################################################################

import arcpy, os, glob

# Folder with MXDs
mxdFolder = arcpy.GetParameterAsText(0)
# Folder where PDFs will be stored
jpegFolder = arcpy.GetParameterAsText(1)

mxdList = glob.glob(mxdFolder + os.sep + '*.mxd')

for mxd in mxdList:
    mapdoc = arcpy.mapping.MapDocument(mxd)
    jpeg = mxd.split('\\')[-1][:-3] + 'jpeg'
    jpeg = jpegFolder + os.sep + jpeg
    arcpy.mapping.ExportToJPEG(mapdoc, jpeg)